import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Clock, Target, Edit, Trash2 } from 'lucide-react';

interface AppCardProps {
  appName: string;
  totalTime: number;
  category: string;
  dailyLimit?: number;
  onEdit: () => void;
  onDelete: () => void;
}

export default function AppCard({ 
  appName, 
  totalTime, 
  category, 
  dailyLimit = 120, 
  onEdit, 
  onDelete 
}: AppCardProps) {
  const usagePercentage = Math.min((totalTime / dailyLimit) * 100, 100);
  const isOverLimit = totalTime > dailyLimit;
  const remainingTime = Math.max(dailyLimit - totalTime, 0);

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  const getProgressColor = () => {
    if (usagePercentage >= 90) return 'bg-red-500';
    if (usagePercentage >= 60) return 'bg-yellow-500';
    if (usagePercentage >= 30) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const getCategoryColor = (cat: string) => {
    const colors: { [key: string]: string } = {
      'Social Media': 'bg-pink-100 text-pink-800',
      'Entertainment': 'bg-purple-100 text-purple-800',
      'Productivity': 'bg-green-100 text-green-800',
      'Education': 'bg-blue-100 text-blue-800',
      'Games': 'bg-orange-100 text-orange-800',
      'News': 'bg-gray-100 text-gray-800',
      'Shopping': 'bg-yellow-100 text-yellow-800',
      'Health & Fitness': 'bg-emerald-100 text-emerald-800',
      'Communication': 'bg-cyan-100 text-cyan-800',
      'Other': 'bg-slate-100 text-slate-800'
    };
    return colors[cat] || colors['Other'];
  };

  return (
    <Card className={`relative ${isOverLimit ? 'border-red-200 bg-red-50' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold text-gray-900 mb-1">
              {appName}
            </CardTitle>
            <Badge variant="secondary" className={getCategoryColor(category)}>
              {category}
            </Badge>
          </div>
          <div className="flex space-x-1">
            <Button variant="ghost" size="sm" onClick={onEdit}>
              <Edit className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={onDelete}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Usage Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Clock className="w-4 h-4 text-gray-500 mr-1" />
              <span className="text-sm text-gray-600">Used Today</span>
            </div>
            <div className={`text-2xl font-bold ${isOverLimit ? 'text-red-600' : 'text-blue-600'}`}>
              {formatTime(totalTime)}
            </div>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Target className="w-4 h-4 text-gray-500 mr-1" />
              <span className="text-sm text-gray-600">Remaining</span>
            </div>
            <div className={`text-2xl font-bold ${isOverLimit ? 'text-red-600' : 'text-green-600'}`}>
              {isOverLimit ? `+${formatTime(totalTime - dailyLimit)}` : formatTime(remainingTime)}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Daily Limit Progress</span>
            <span className={`text-sm font-medium ${isOverLimit ? 'text-red-600' : 'text-gray-900'}`}>
              {usagePercentage.toFixed(0)}%
            </span>
          </div>
          <div className="relative">
            <Progress value={Math.min(usagePercentage, 100)} className="h-2" />
            <div 
              className={`absolute top-0 left-0 h-2 rounded-full transition-all ${getProgressColor()}`}
              style={{ width: `${Math.min(usagePercentage, 100)}%` }}
            />
          </div>
          <div className="text-xs text-gray-500 text-center">
            Daily limit: {formatTime(dailyLimit)}
          </div>
        </div>

        {/* Status Indicators */}
        {usagePercentage >= 90 && (
          <div className="bg-red-100 border border-red-200 rounded-lg p-3">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
              <span className="text-sm text-red-800 font-medium">
                {isOverLimit ? 'Limit exceeded!' : 'Approaching daily limit'}
              </span>
            </div>
          </div>
        )}

        {usagePercentage >= 60 && usagePercentage < 90 && (
          <div className="bg-yellow-100 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
              <span className="text-sm text-yellow-800 font-medium">
                60% of daily limit used
              </span>
            </div>
          </div>
        )}

        {usagePercentage >= 30 && usagePercentage < 60 && (
          <div className="bg-blue-100 border border-blue-200 rounded-lg p-3">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
              <span className="text-sm text-blue-800 font-medium">
                30% of daily limit used
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}