import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Plus, X } from 'lucide-react';

interface TimeEntry {
  appName: string;
  category: string;
  duration: number;
  date: string;
  notes?: string;
}

interface TimeTrackerProps {
  onEntryAdded: (entry: Omit<TimeEntry, 'id'>) => void;
  onCancel: () => void;
}

const categories = [
  'Social Media',
  'Entertainment',
  'Productivity',
  'Education',
  'Games',
  'News',
  'Shopping',
  'Health & Fitness',
  'Communication',
  'Other'
];

const commonApps = [
  'WhatsApp', 'Instagram', 'Facebook', 'Twitter', 'TikTok',
  'YouTube', 'Netflix', 'Spotify', 'Gmail', 'Chrome',
  'Microsoft Word', 'Excel', 'PowerPoint', 'Zoom', 'Teams',
  'Slack', 'Discord', 'LinkedIn', 'Pinterest', 'Snapchat'
];

export default function TimeTracker({ onEntryAdded, onCancel }: TimeTrackerProps) {
  const [formData, setFormData] = useState({
    appName: '',
    category: '',
    hours: '',
    minutes: '',
    notes: ''
  });
  const [isTimerMode, setIsTimerMode] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [timerActive, setTimerActive] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const hours = parseInt(formData.hours) || 0;
    const minutes = parseInt(formData.minutes) || 0;
    const totalMinutes = (hours * 60) + minutes;

    if (!formData.appName || !formData.category || totalMinutes === 0) {
      alert('Please fill in all required fields');
      return;
    }

    const entry: Omit<TimeEntry, 'id'> = {
      appName: formData.appName,
      category: formData.category,
      duration: totalMinutes,
      date: new Date().toISOString(),
      notes: formData.notes || undefined
    };

    onEntryAdded(entry);
  };

  const handleTimerSubmit = () => {
    if (!formData.appName || !formData.category || timerSeconds === 0) {
      alert('Please fill in all required fields and run the timer');
      return;
    }

    const entry: Omit<TimeEntry, 'id'> = {
      appName: formData.appName,
      category: formData.category,
      duration: Math.floor(timerSeconds / 60),
      date: new Date().toISOString(),
      notes: formData.notes || undefined
    };

    onEntryAdded(entry);
  };

  const startTimer = () => {
    setTimerActive(true);
    const interval = setInterval(() => {
      setTimerSeconds(prev => {
        if (!timerActive) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 1000);
  };

  const stopTimer = () => {
    setTimerActive(false);
  };

  const resetTimer = () => {
    setTimerActive(false);
    setTimerSeconds(0);
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Mode Toggle */}
      <div className="flex space-x-2">
        <Button
          variant={!isTimerMode ? 'default' : 'outline'}
          onClick={() => setIsTimerMode(false)}
          className="flex-1"
        >
          Manual Entry
        </Button>
        <Button
          variant={isTimerMode ? 'default' : 'outline'}
          onClick={() => setIsTimerMode(true)}
          className="flex-1"
        >
          <Clock className="w-4 h-4 mr-2" />
          Timer Mode
        </Button>
      </div>

      {!isTimerMode ? (
        /* Manual Entry Form */
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="app-name">App/Activity Name *</Label>
              <div className="space-y-2">
                <Input
                  id="app-name"
                  placeholder="Enter app name or select from common apps"
                  value={formData.appName}
                  onChange={(e) => setFormData({ ...formData, appName: e.target.value })}
                  required
                />
                <div className="flex flex-wrap gap-2">
                  {commonApps.slice(0, 6).map((app) => (
                    <Button
                      key={app}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData({ ...formData, appName: app })}
                    >
                      {app}
                    </Button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Duration *</Label>
            <div className="flex space-x-4">
              <div className="flex-1">
                <Label htmlFor="hours" className="text-sm text-gray-600">Hours</Label>
                <Input
                  id="hours"
                  type="number"
                  min="0"
                  max="23"
                  placeholder="0"
                  value={formData.hours}
                  onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="minutes" className="text-sm text-gray-600">Minutes</Label>
                <Input
                  id="minutes"
                  type="number"
                  min="0"
                  max="59"
                  placeholder="0"
                  value={formData.minutes}
                  onChange={(e) => setFormData({ ...formData, minutes: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Add any additional notes about this usage session..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex space-x-4">
            <Button type="submit" className="flex-1">
              <Plus className="w-4 h-4 mr-2" />
              Add Entry
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </form>
      ) : (
        /* Timer Mode */
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="timer-app-name">App/Activity Name *</Label>
              <Input
                id="timer-app-name"
                placeholder="Enter app name"
                value={formData.appName}
                onChange={(e) => setFormData({ ...formData, appName: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="timer-category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Timer Display */}
          <Card>
            <CardContent className="py-8 text-center">
              <div className="text-6xl font-mono font-bold text-blue-600 mb-6">
                {formatTime(timerSeconds)}
              </div>
              <div className="flex justify-center space-x-4">
                {!timerActive ? (
                  <Button onClick={startTimer} size="lg">
                    Start Timer
                  </Button>
                ) : (
                  <Button onClick={stopTimer} variant="destructive" size="lg">
                    Stop Timer
                  </Button>
                )}
                <Button onClick={resetTimer} variant="outline" size="lg">
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Label htmlFor="timer-notes">Notes (Optional)</Label>
            <Textarea
              id="timer-notes"
              placeholder="Add any additional notes about this session..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex space-x-4">
            <Button onClick={handleTimerSubmit} className="flex-1" disabled={timerSeconds === 0}>
              <Plus className="w-4 h-4 mr-2" />
              Save Session
            </Button>
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}