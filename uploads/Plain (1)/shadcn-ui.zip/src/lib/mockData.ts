// Mock data and utility functions for Plain app

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  aiAgent: 'dan' | 'jemma';
  subscriptionStatus: 'trial' | 'active' | 'expired';
  trialDaysLeft: number;
  createdAt: string;
}

export interface TimeEntry {
  id: string;
  appName: string;
  category: string;
  duration: number;
  date: string;
  notes?: string;
}

export interface Goal {
  id: string;
  appName: string;
  dailyLimit: number;
  weeklyLimit: number;
  isActive: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  duration: string;
  features: string[];
  recommended?: boolean;
}

// Sample users for demo
export const sampleUsers: User[] = [
  {
    id: '1',
    email: 'demo@plain.app',
    firstName: 'Demo',
    lastName: 'User',
    aiAgent: 'dan',
    subscriptionStatus: 'trial',
    trialDaysLeft: 5,
    createdAt: new Date().toISOString()
  }
];

// Sample time entries for demo
export const sampleTimeEntries: TimeEntry[] = [
  {
    id: '1',
    appName: 'Instagram',
    category: 'Social Media',
    duration: 45,
    date: new Date().toISOString(),
    notes: 'Scrolling through feed during lunch break'
  },
  {
    id: '2',
    appName: 'YouTube',
    category: 'Entertainment',
    duration: 120,
    date: new Date().toISOString(),
    notes: 'Watching educational videos'
  },
  {
    id: '3',
    appName: 'WhatsApp',
    category: 'Communication',
    duration: 30,
    date: new Date().toISOString(),
    notes: 'Family group chat'
  }
];

// App categories with colors
export const appCategories = [
  { name: 'Social Media', color: '#EC4899', icon: '📱' },
  { name: 'Entertainment', color: '#8B5CF6', icon: '🎬' },
  { name: 'Productivity', color: '#10B981', icon: '💼' },
  { name: 'Education', color: '#3B82F6', icon: '📚' },
  { name: 'Games', color: '#F59E0B', icon: '🎮' },
  { name: 'News', color: '#6B7280', icon: '📰' },
  { name: 'Shopping', color: '#EAB308', icon: '🛒' },
  { name: 'Health & Fitness', color: '#059669', icon: '💪' },
  { name: 'Communication', color: '#06B6D4', icon: '💬' },
  { name: 'Other', color: '#64748B', icon: '📂' }
];

// Common apps with their typical categories
export const commonApps = [
  { name: 'WhatsApp', category: 'Communication' },
  { name: 'Instagram', category: 'Social Media' },
  { name: 'Facebook', category: 'Social Media' },
  { name: 'Twitter', category: 'Social Media' },
  { name: 'TikTok', category: 'Social Media' },
  { name: 'YouTube', category: 'Entertainment' },
  { name: 'Netflix', category: 'Entertainment' },
  { name: 'Spotify', category: 'Entertainment' },
  { name: 'Gmail', category: 'Communication' },
  { name: 'Chrome', category: 'Productivity' },
  { name: 'Microsoft Word', category: 'Productivity' },
  { name: 'Excel', category: 'Productivity' },
  { name: 'PowerPoint', category: 'Productivity' },
  { name: 'Zoom', category: 'Communication' },
  { name: 'Teams', category: 'Communication' },
  { name: 'Slack', category: 'Communication' },
  { name: 'Discord', category: 'Communication' },
  { name: 'LinkedIn', category: 'Social Media' },
  { name: 'Pinterest', category: 'Social Media' },
  { name: 'Snapchat', category: 'Social Media' }
];

// AI Agent personalities
export const aiAgents = {
  dan: {
    name: 'Dan',
    personality: 'Analytical and data-driven',
    description: 'Provides detailed insights and actionable recommendations based on data analysis.',
    strengths: ['Data Analysis', 'Pattern Recognition', 'Goal Optimization', 'Performance Metrics'],
    communicationStyle: 'Direct, factual, and solution-oriented'
  },
  jemma: {
    name: 'Jemma',
    personality: 'Empathetic and supportive',
    description: 'Focuses on mental wellness and positive reinforcement with a caring approach.',
    strengths: ['Mental Wellness', 'Emotional Support', 'Habit Building', 'Positive Reinforcement'],
    communicationStyle: 'Warm, encouraging, and mindful'
  }
};

// Subscription plans
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'monthly',
    name: 'Monthly Plan',
    price: 3000,
    duration: 'per month',
    features: [
      'Manual time tracking',
      'AI-powered insights',
      'Weekly email reports',
      'Goal setting & tracking',
      'Basic analytics dashboard',
      'Mobile responsive design'
    ]
  },
  {
    id: 'yearly',
    name: 'Yearly Plan',
    price: 30000,
    duration: 'per year',
    recommended: true,
    features: [
      'Everything in Monthly Plan',
      'Priority support',
      'Advanced analytics',
      'Data export features',
      'Custom AI agent responses',
      'Save ₦6,000 annually'
    ]
  }
];

// Utility functions
export const formatTime = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours > 0) {
    return `${hours}h ${mins}m`;
  }
  return `${mins}m`;
};

export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

export const calculateUsagePercentage = (used: number, limit: number): number => {
  return Math.min((used / limit) * 100, 100);
};

export const getUsageStatus = (percentage: number): {
  status: 'safe' | 'warning' | 'danger' | 'exceeded';
  color: string;
  message: string;
} => {
  if (percentage >= 100) {
    return {
      status: 'exceeded',
      color: 'text-red-600',
      message: 'Limit exceeded!'
    };
  } else if (percentage >= 90) {
    return {
      status: 'danger',
      color: 'text-red-600',
      message: 'Approaching limit'
    };
  } else if (percentage >= 60) {
    return {
      status: 'warning',
      color: 'text-yellow-600',
      message: '60% of limit used'
    };
  } else if (percentage >= 30) {
    return {
      status: 'warning',
      color: 'text-blue-600',
      message: '30% of limit used'
    };
  } else {
    return {
      status: 'safe',
      color: 'text-green-600',
      message: 'Within safe limits'
    };
  }
};

// Generate AI insights based on usage patterns
export const generateAIInsights = (
  timeEntries: TimeEntry[],
  aiAgent: 'dan' | 'jemma'
): string[] => {
  const totalTime = timeEntries.reduce((sum, entry) => sum + entry.duration, 0);
  const avgDailyTime = totalTime / 7;
  const appUsage = timeEntries.reduce((acc, entry) => {
    acc[entry.appName] = (acc[entry.appName] || 0) + entry.duration;
    return acc;
  }, {} as Record<string, number>);
  
  const mostUsedApp = Object.entries(appUsage).sort(([,a], [,b]) => b - a)[0];

  if (aiAgent === 'dan') {
    return [
      `📊 Data Analysis: You've tracked ${timeEntries.length} sessions totaling ${formatTime(totalTime)} this week.`,
      `🎯 Performance Insight: Your average daily usage is ${formatTime(avgDailyTime)}.`,
      `📱 Top App: ${mostUsedApp?.[0] || 'N/A'} is your most used application with ${formatTime(mostUsedApp?.[1] || 0)}.`,
      `📈 Optimization: Consider setting stricter limits for high-usage apps to improve productivity.`,
      `💡 Recommendation: Try the Pomodoro Technique - 25 minutes of focused work followed by 5-minute breaks.`
    ];
  } else {
    return [
      `🌟 Wellness Check: You're doing great by tracking your digital habits! Awareness is the first step.`,
      `💚 Mindful Usage: Remember to take breaks and be present in the moment outside of screen time.`,
      `🎯 Gentle Reminder: Consider setting compassionate boundaries with your most-used apps.`,
      `🧘 Mental Health Tip: Regular digital detox periods can help reduce stress and improve focus.`,
      `🌈 Positive Progress: Every small step towards digital wellness is meaningful. Keep going!`
    ];
  }
};

// Mock API functions
export const mockAPI = {
  // User authentication
  login: async (email: string, password: string): Promise<User | null> => {
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
    const users = JSON.parse(localStorage.getItem('plain_users') || '[]');
    return users.find((u: User) => u.email === email) || null;
  },

  // Register new user
  register: async (userData: Omit<User, 'id' | 'createdAt'>): Promise<User> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    
    const users = JSON.parse(localStorage.getItem('plain_users') || '[]');
    users.push(newUser);
    localStorage.setItem('plain_users', JSON.stringify(users));
    
    return newUser;
  },

  // Process payment (mock Intasend integration)
  processPayment: async (planId: string, amount: number): Promise<{ success: boolean; transactionId: string }> => {
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate payment processing
    return {
      success: Math.random() > 0.1, // 90% success rate
      transactionId: `INTASEND_${Date.now()}`
    };
  },

  // Send email report (mock SendGrid integration)
  sendEmailReport: async (email: string, content: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log(`Email sent to ${email}:`, content);
    return true;
  }
};

// Initialize demo data
export const initializeDemoData = (): void => {
  // Only initialize if no data exists
  if (!localStorage.getItem('plain_users')) {
    localStorage.setItem('plain_users', JSON.stringify(sampleUsers));
  }
  
  if (!localStorage.getItem('plain_time_entries')) {
    localStorage.setItem('plain_time_entries', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('plain_stats')) {
    localStorage.setItem('plain_stats', JSON.stringify({
      todayTotal: 0,
      weeklyTotal: 0,
      mostUsedApp: 'No data yet',
      goalsAchieved: 0,
      totalGoals: 0
    }));
  }
};