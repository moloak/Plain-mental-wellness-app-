import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, Clock, Target, Mail, Download, ArrowLeft } from 'lucide-react';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  aiAgent: 'dan' | 'jemma';
  subscriptionStatus: 'trial' | 'active' | 'expired';
  trialDaysLeft: number;
}

interface TimeEntry {
  id: string;
  appName: string;
  category: string;
  duration: number;
  date: string;
  notes?: string;
}

interface ChartData {
  name: string;
  value: number;
  color?: string;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#F97316', '#06B6D4'];

export default function Analytics() {
  const [user, setUser] = useState<User | null>(null);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);
  const [weeklyData, setWeeklyData] = useState<ChartData[]>([]);
  const [categoryData, setCategoryData] = useState<ChartData[]>([]);
  const [appData, setAppData] = useState<ChartData[]>([]);
  const [insights, setInsights] = useState<string[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('plain_user');
    if (!userData) {
      navigate('/auth');
      return;
    }

    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);

    // Load time entries
    const entries = JSON.parse(localStorage.getItem('plain_time_entries') || '[]');
    setTimeEntries(entries);

    // Process data for charts
    processAnalyticsData(entries, parsedUser);
  }, [navigate]);

  const processAnalyticsData = (entries: TimeEntry[], userData: User) => {
    // Weekly data (last 7 days)
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date.toDateString();
    });

    const weeklyUsage = last7Days.map(dateStr => {
      const dayEntries = entries.filter(entry => new Date(entry.date).toDateString() === dateStr);
      const totalMinutes = dayEntries.reduce((sum, entry) => sum + entry.duration, 0);
      return {
        name: new Date(dateStr).toLocaleDateString('en-US', { weekday: 'short' }),
        value: totalMinutes
      };
    });
    setWeeklyData(weeklyUsage);

    // Category data
    const categoryMap = new Map<string, number>();
    entries.forEach(entry => {
      const current = categoryMap.get(entry.category) || 0;
      categoryMap.set(entry.category, current + entry.duration);
    });

    const categoryChartData = Array.from(categoryMap.entries()).map(([name, value], index) => ({
      name,
      value,
      color: COLORS[index % COLORS.length]
    }));
    setCategoryData(categoryChartData);

    // Top apps data
    const appMap = new Map<string, number>();
    entries.forEach(entry => {
      const current = appMap.get(entry.appName) || 0;
      appMap.set(entry.appName, current + entry.duration);
    });

    const topApps = Array.from(appMap.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([name, value]) => ({ name, value }));
    setAppData(topApps);

    // Generate AI insights
    generateInsights(entries, userData);
  };

  const generateInsights = (entries: TimeEntry[], userData: User) => {
    const totalTime = entries.reduce((sum, entry) => sum + entry.duration, 0);
    const avgDailyTime = totalTime / 7;
    const mostUsedApp = appData.length > 0 ? appData[0].name : 'N/A';
    
    const aiInsights = userData.aiAgent === 'dan' ? [
      `📊 Data Analysis: You've tracked ${entries.length} sessions totaling ${Math.floor(totalTime / 60)} hours this week.`,
      `🎯 Performance Insight: Your average daily usage is ${Math.floor(avgDailyTime / 60)}h ${Math.floor(avgDailyTime % 60)}m.`,
      `📱 Top App: ${mostUsedApp} is your most used application. Consider setting usage limits.`,
      `📈 Trend: ${weeklyData.length > 1 && weeklyData[6].value > weeklyData[0].value ? 'Usage increased' : 'Usage decreased'} compared to last week.`,
      `💡 Recommendation: Try the 20-20-20 rule - every 20 minutes, look at something 20 feet away for 20 seconds.`
    ] : [
      `🌟 Wellness Check: You're doing great by tracking your digital habits! Keep it up.`,
      `💚 Mindful Usage: Remember, awareness is the first step to building healthier digital habits.`,
      `🎯 Goal Setting: Consider setting daily limits for your most-used apps to maintain balance.`,
      `🧘 Mental Health Tip: Take regular breaks from screens to reduce eye strain and mental fatigue.`,
      `🌈 Positive Progress: Every small step towards digital wellness counts. You're on the right path!`
    ];

    setInsights(aiInsights);
  };

  const handleSendWeeklyReport = () => {
    // Simulate sending email report
    alert(`Weekly report sent to ${user?.email} by ${user?.aiAgent === 'dan' ? 'Dan' : 'Jemma'}!`);
  };

  const handleExportData = () => {
    const dataToExport = {
      user: user,
      timeEntries: timeEntries,
      analytics: {
        weeklyData,
        categoryData,
        appData,
        insights
      },
      exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `plain-analytics-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  const totalWeeklyTime = weeklyData.reduce((sum, day) => sum + day.value, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Plain Analytics</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={handleSendWeeklyReport}>
              <Mail className="w-4 h-4 mr-2" />
              Send Report
            </Button>
            <Button variant="outline" onClick={handleExportData}>
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
          <p className="text-gray-600">
            Insights and recommendations from {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'}, your AI wellness companion.
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Weekly Total
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {Math.floor(totalWeeklyTime / 60)}h {totalWeeklyTime % 60}m
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Target className="w-4 h-4 mr-2" />
                Apps Tracked
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {appData.length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <TrendingUp className="w-4 h-4 mr-2" />
                Sessions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {timeEntries.length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Daily Average
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {Math.floor(totalWeeklyTime / 7 / 60)}h {Math.floor((totalWeeklyTime / 7) % 60)}m
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Weekly Usage Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Weekly Usage Pattern</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={weeklyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value} minutes`, 'Usage']} />
                      <Bar dataKey="value" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Category Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Usage by Category</CardTitle>
                </CardHeader>
                <CardContent>
                  {categoryData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} minutes`, 'Usage']} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-gray-500">
                      No category data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Top Apps */}
            <Card>
              <CardHeader>
                <CardTitle>Top 5 Most Used Apps</CardTitle>
              </CardHeader>
              <CardContent>
                {appData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={appData} layout="horizontal">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip formatter={(value) => [`${value} minutes`, 'Usage']} />
                      <Bar dataKey="value" fill="#10B981" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[300px] flex items-center justify-center text-gray-500">
                    No app usage data available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Usage Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} minutes`, 'Usage']} />
                    <Line type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  AI Insights from {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'}
                  <Badge variant="secondary" className="ml-2 capitalize">
                    {user.aiAgent}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {insights.map((insight, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-800">{insight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Email Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Get personalized weekly reports from {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'} with detailed analytics and improvement suggestions.
                </p>
                <Button onClick={handleSendWeeklyReport} className="w-full">
                  <Mail className="w-4 h-4 mr-2" />
                  Send This Week's Report to {user.email}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}