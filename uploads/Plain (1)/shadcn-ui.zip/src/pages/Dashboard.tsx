import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { Clock, Plus, TrendingUp, Target, Settings } from 'lucide-react';
import TimeTracker from '@/components/TimeTracker';
import AppCard from '@/components/AppCard';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  aiAgent: 'dan' | 'jemma';
  subscriptionStatus: 'trial' | 'active' | 'expired';
  trialDaysLeft: number;
}

interface TimeEntry {
  id: string;
  appName: string;
  category: string;
  duration: number;
  date: string;
  notes?: string;
}

interface AppUsage {
  appName: string;
  totalTime: number;
  category: string;
  dailyLimit?: number;
  weeklyLimit?: number;
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);
  const [appUsages, setAppUsages] = useState<AppUsage[]>([]);
  const [showTimeTracker, setShowTimeTracker] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('plain_user');
    if (!userData) {
      navigate('/auth');
      return;
    }

    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);

    // Load time entries
    const entries = JSON.parse(localStorage.getItem('plain_time_entries') || '[]');
    setTimeEntries(entries);

    // Calculate app usages
    calculateAppUsages(entries);
  }, [navigate]);

  const calculateAppUsages = (entries: TimeEntry[]) => {
    const today = new Date().toDateString();
    const todayEntries = entries.filter(entry => new Date(entry.date).toDateString() === today);
    
    const usageMap = new Map<string, AppUsage>();
    
    todayEntries.forEach(entry => {
      const existing = usageMap.get(entry.appName);
      if (existing) {
        existing.totalTime += entry.duration;
      } else {
        usageMap.set(entry.appName, {
          appName: entry.appName,
          totalTime: entry.duration,
          category: entry.category,
          dailyLimit: 120, // Default 2 hours
          weeklyLimit: 840 // Default 14 hours
        });
      }
    });

    setAppUsages(Array.from(usageMap.values()));
  };

  const handleTimeEntryAdded = (newEntry: Omit<TimeEntry, 'id'>) => {
    const entry: TimeEntry = {
      ...newEntry,
      id: Date.now().toString()
    };

    const updatedEntries = [...timeEntries, entry];
    setTimeEntries(updatedEntries);
    localStorage.setItem('plain_time_entries', JSON.stringify(updatedEntries));
    
    // Update stats
    const stats = JSON.parse(localStorage.getItem('plain_stats') || '{}');
    stats.todayTotal = (stats.todayTotal || 0) + entry.duration;
    stats.weeklyTotal = (stats.weeklyTotal || 0) + entry.duration;
    stats.mostUsedApp = entry.appName;
    localStorage.setItem('plain_stats', JSON.stringify(stats));

    calculateAppUsages(updatedEntries);
    setShowTimeTracker(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('plain_user');
    navigate('/');
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  const todayTotal = appUsages.reduce((total, app) => total + app.totalTime, 0);
  const totalGoals = appUsages.length;
  const goalsAchieved = appUsages.filter(app => app.totalTime <= (app.dailyLimit || 120)).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">P</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Plain</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant={user.subscriptionStatus === 'trial' ? 'secondary' : 'default'}>
              {user.subscriptionStatus === 'trial' ? `Trial: ${user.trialDaysLeft} days left` : 'Premium'}
            </Badge>
            <Button variant="outline" onClick={() => navigate('/analytics')}>
              Analytics
            </Button>
            <Button variant="outline" onClick={() => navigate('/subscription')}>
              Subscription
            </Button>
            <Button variant="ghost" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Time Tracking Dashboard
          </h1>
          <p className="text-gray-600">
            Track your app usage and monitor your digital wellness goals with {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'}.
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Today's Total
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {Math.floor(todayTotal / 60)}h {todayTotal % 60}m
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Target className="w-4 h-4 mr-2" />
                Goals Met
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {goalsAchieved}/{totalGoals}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <TrendingUp className="w-4 h-4 mr-2" />
                Apps Tracked
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {appUsages.length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Settings className="w-4 h-4 mr-2" />
                AI Agent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-semibold text-orange-600 capitalize">
                {user.aiAgent}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Quick Actions</h2>
            <Button onClick={() => setShowTimeTracker(true)} className="flex items-center">
              <Plus className="w-4 h-4 mr-2" />
              Track Time
            </Button>
          </div>

          {showTimeTracker && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Add Time Entry</CardTitle>
              </CardHeader>
              <CardContent>
                <TimeTracker 
                  onEntryAdded={handleTimeEntryAdded}
                  onCancel={() => setShowTimeTracker(false)}
                />
              </CardContent>
            </Card>
          )}
        </div>

        {/* App Usage Cards */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Today's App Usage</h2>
          {appUsages.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No time entries yet</h3>
                <p className="text-gray-600 mb-4">
                  Start tracking your app usage to see insights and analytics.
                </p>
                <Button onClick={() => setShowTimeTracker(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Entry
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {appUsages.map((app) => (
                <AppCard
                  key={app.appName}
                  appName={app.appName}
                  totalTime={app.totalTime}
                  category={app.category}
                  dailyLimit={app.dailyLimit}
                  onEdit={() => {}}
                  onDelete={() => {}}
                />
              ))}
            </div>
          )}
        </div>

        {/* Recent Entries */}
        {timeEntries.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Entries</h2>
            <Card>
              <CardContent className="p-0">
                <div className="divide-y">
                  {timeEntries.slice(-5).reverse().map((entry) => (
                    <div key={entry.id} className="p-4 flex justify-between items-center">
                      <div>
                        <div className="font-medium text-gray-900">{entry.appName}</div>
                        <div className="text-sm text-gray-600">
                          {entry.category} • {Math.floor(entry.duration / 60)}h {entry.duration % 60}m
                        </div>
                        {entry.notes && (
                          <div className="text-sm text-gray-500 mt-1">{entry.notes}</div>
                        )}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(entry.date).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}