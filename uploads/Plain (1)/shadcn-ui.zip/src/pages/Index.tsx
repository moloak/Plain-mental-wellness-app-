import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, TrendingUp, Target, Mail } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  aiAgent: 'dan' | 'jemma';
  subscriptionStatus: 'trial' | 'active' | 'expired';
  trialDaysLeft: number;
}

interface DashboardStats {
  todayTotal: number;
  weeklyTotal: number;
  mostUsedApp: string;
  goalsAchieved: number;
  totalGoals: number;
}

export default function Index() {
  const [user, setUser] = useState<User | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('plain_user');
    if (userData) {
      const parsedUser = JSON.parse(userData);
      setUser(parsedUser);
      
      // Load dashboard stats
      const statsData = localStorage.getItem('plain_stats');
      if (statsData) {
        setStats(JSON.parse(statsData));
      } else {
        // Initialize default stats
        const defaultStats: DashboardStats = {
          todayTotal: 0,
          weeklyTotal: 0,
          mostUsedApp: 'No data yet',
          goalsAchieved: 0,
          totalGoals: 0
        };
        setStats(defaultStats);
        localStorage.setItem('plain_stats', JSON.stringify(defaultStats));
      }
    }
  }, []);

  const handleGetStarted = () => {
    navigate('/auth');
  };

  const handleTrackTime = () => {
    navigate('/dashboard');
  };

  const handleViewAnalytics = () => {
    navigate('/analytics');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
        {/* Header */}
        <header className="border-b bg-white/80 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Plain</span>
            </div>
            <Button onClick={handleGetStarted} className="bg-blue-600 hover:bg-blue-700">
              Get Started
            </Button>
          </div>
        </header>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-20 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Take Control of Your
              <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Digital Wellness</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Monitor your app usage, get AI-powered insights, and build healthier digital habits with Plain - your personal mental health companion.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={handleGetStarted} size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
                Start 7-Day Free Trial
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Learn More
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="container mx-auto px-4 py-20">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Plain?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our AI-powered platform helps you understand and improve your digital habits with personalized insights and actionable recommendations.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <Clock className="w-12 h-12 text-blue-600 mb-4" />
                <CardTitle>Manual Time Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Track your app usage manually with our intuitive interface. Set goals and monitor your progress in real-time.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <TrendingUp className="w-12 h-12 text-green-600 mb-4" />
                <CardTitle>AI-Powered Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Get personalized insights from Dan or Jemma, our AI agents who analyze your patterns and provide actionable recommendations.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <Mail className="w-12 h-12 text-purple-600 mb-4" />
                <CardTitle>Weekly Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Receive detailed weekly reports via email with progress updates, achievements, and personalized improvement suggestions.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="bg-gray-50 py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
              <p className="text-gray-600">Start with a 7-day free trial, then choose the plan that works for you.</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <Card className="border-2 border-blue-200 shadow-lg">
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">Monthly Plan</CardTitle>
                  <div className="text-4xl font-bold text-blue-600">₦3,000</div>
                  <p className="text-gray-600">per month</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Manual time tracking
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      AI-powered insights
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Weekly email reports
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Goal setting & tracking
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2 border-green-200 shadow-lg relative">
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600">
                  Best Value
                </Badge>
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">Yearly Plan</CardTitle>
                  <div className="text-4xl font-bold text-green-600">₦30,000</div>
                  <p className="text-gray-600">per year</p>
                  <p className="text-sm text-green-600 font-medium">Save ₦6,000 annually</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Everything in Monthly
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Priority support
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Advanced analytics
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      Data export features
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Transform Your Digital Habits?</h2>
          <p className="text-xl text-gray-600 mb-8">Join thousands of users who have improved their digital wellness with Plain.</p>
          <Button onClick={handleGetStarted} size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
            Start Your Free Trial Today
          </Button>
        </section>
      </div>
    );
  }

  // Dashboard view for logged-in users
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">P</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Plain</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant={user.subscriptionStatus === 'trial' ? 'secondary' : 'default'}>
              {user.subscriptionStatus === 'trial' ? `Trial: ${user.trialDaysLeft} days left` : 'Premium'}
            </Badge>
            <Button variant="outline" onClick={() => navigate('/subscription')}>
              Manage Subscription
            </Button>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user.firstName}!
          </h1>
          <p className="text-gray-600">
            Your AI agent {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'} is ready to help you track your digital wellness.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Today's Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {Math.floor(stats?.todayTotal || 0 / 60)}h {(stats?.todayTotal || 0) % 60}m
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Weekly Total</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {Math.floor(stats?.weeklyTotal || 0 / 60)}h {(stats?.weeklyTotal || 0) % 60}m
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Most Used App</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-semibold text-purple-600">
                {stats?.mostUsedApp || 'No data'}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Goals Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {stats?.goalsAchieved || 0}/{stats?.totalGoals || 0}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Quick Time Entry
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Track your app usage for today and stay on top of your digital wellness goals.
              </p>
              <Button onClick={handleTrackTime} className="w-full">
                Track Time Now
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                View Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Explore your usage patterns, trends, and get AI-powered insights from {user.aiAgent === 'dan' ? 'Dan' : 'Jemma'}.
              </p>
              <Button onClick={handleViewAnalytics} variant="outline" className="w-full">
                View Analytics
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}