import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Check, ArrowLeft, Calendar, Crown } from 'lucide-react';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  aiAgent: 'dan' | 'jemma';
  subscriptionStatus: 'trial' | 'active' | 'expired';
  trialDaysLeft: number;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  duration: string;
  features: string[];
  recommended?: boolean;
}

const plans: SubscriptionPlan[] = [
  {
    id: 'monthly',
    name: 'Monthly Plan',
    price: 3000,
    duration: 'per month',
    features: [
      'Manual time tracking',
      'AI-powered insights',
      'Weekly email reports',
      'Goal setting & tracking',
      'Basic analytics dashboard',
      'Mobile responsive design'
    ]
  },
  {
    id: 'yearly',
    name: 'Yearly Plan',
    price: 30000,
    duration: 'per year',
    recommended: true,
    features: [
      'Everything in Monthly Plan',
      'Priority support',
      'Advanced analytics',
      'Data export features',
      'Custom AI agent responses',
      'Save ₦6,000 annually'
    ]
  }
];

export default function Subscription() {
  const [user, setUser] = useState<User | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('plain_user');
    if (!userData) {
      navigate('/auth');
      return;
    }

    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);
  }, [navigate]);

  const handleSubscribe = async (planId: string) => {
    setLoading(true);
    setSelectedPlan(planId);

    try {
      // Simulate Intasend payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Update user subscription status
      if (user) {
        const updatedUser = {
          ...user,
          subscriptionStatus: 'active' as const,
          trialDaysLeft: 0
        };

        // Update localStorage
        localStorage.setItem('plain_user', JSON.stringify(updatedUser));
        
        // Update users array
        const users = JSON.parse(localStorage.getItem('plain_users') || '[]');
        const userIndex = users.findIndex((u: any) => u.id === user.id);
        if (userIndex !== -1) {
          users[userIndex] = updatedUser;
          localStorage.setItem('plain_users', JSON.stringify(users));
        }

        setUser(updatedUser);
        setPaymentSuccess(true);
      }
    } catch (error) {
      console.error('Payment failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelSubscription = () => {
    if (user) {
      const updatedUser = {
        ...user,
        subscriptionStatus: 'expired' as const
      };

      localStorage.setItem('plain_user', JSON.stringify(updatedUser));
      setUser(updatedUser);
    }
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Plain Subscription</span>
            </div>
          </div>
          <Badge variant={user.subscriptionStatus === 'trial' ? 'secondary' : user.subscriptionStatus === 'active' ? 'default' : 'destructive'}>
            {user.subscriptionStatus === 'trial' ? `Trial: ${user.trialDaysLeft} days left` : 
             user.subscriptionStatus === 'active' ? 'Premium Active' : 'Subscription Expired'}
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Unlock the full potential of Plain with AI-powered insights, advanced analytics, and personalized recommendations.
          </p>
        </div>

        {/* Current Status */}
        {user.subscriptionStatus === 'trial' && (
          <Alert className="mb-8">
            <Calendar className="h-4 w-4" />
            <AlertDescription>
              You have {user.trialDaysLeft} days left in your free trial. Subscribe now to continue enjoying all features.
            </AlertDescription>
          </Alert>
        )}

        {user.subscriptionStatus === 'active' && (
          <Alert className="mb-8">
            <Crown className="h-4 w-4" />
            <AlertDescription>
              You're currently on a Premium plan. Thank you for supporting Plain!
            </AlertDescription>
          </Alert>
        )}

        {paymentSuccess && (
          <Alert className="mb-8">
            <Check className="h-4 w-4" />
            <AlertDescription>
              Payment successful! Welcome to Plain Premium. You now have access to all features.
            </AlertDescription>
          </Alert>
        )}

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-8">
          {plans.map((plan) => (
            <Card key={plan.id} className={`relative ${plan.recommended ? 'border-2 border-green-500 shadow-lg' : 'border shadow-md'}`}>
              {plan.recommended && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600">
                  Best Value
                </Badge>
              )}
              
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="text-4xl font-bold text-blue-600">₦{plan.price.toLocaleString()}</div>
                <p className="text-gray-600">{plan.duration}</p>
                {plan.id === 'yearly' && (
                  <p className="text-sm text-green-600 font-medium">Save ₦6,000 annually</p>
                )}
              </CardHeader>
              
              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {user.subscriptionStatus !== 'active' ? (
                  <Button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={loading && selectedPlan === plan.id}
                    className={`w-full ${plan.recommended ? 'bg-green-600 hover:bg-green-700' : ''}`}
                  >
                    {loading && selectedPlan === plan.id ? (
                      'Processing...'
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4 mr-2" />
                        Subscribe Now
                      </>
                    )}
                  </Button>
                ) : (
                  <Button variant="outline" className="w-full" disabled>
                    Current Plan
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Payment Information */}
        <Card className="max-w-2xl mx-auto mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="w-5 h-5 mr-2" />
              Payment Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Secure Payment</h4>
                <p className="text-sm text-gray-600">
                  All payments are processed securely through Intasend, Nigeria's trusted payment gateway.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 mb-2">7-Day Free Trial</h4>
                <p className="text-sm text-gray-600">
                  New users get a 7-day free trial to explore all features before subscribing.
                </p>
              </div>
            </div>
            
            <div className="border-t pt-4">
              <h4 className="font-medium text-gray-900 mb-2">Accepted Payment Methods</h4>
              <div className="flex space-x-4 text-sm text-gray-600">
                <span>• Bank Transfer</span>
                <span>• Card Payment</span>
                <span>• Mobile Money</span>
                <span>• USSD</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Management */}
        {user.subscriptionStatus === 'active' && (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Manage Subscription</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">Premium Plan</div>
                  <div className="text-sm text-gray-600">Active subscription</div>
                </div>
                <Badge variant="default">Active</Badge>
              </div>
              
              <div className="flex space-x-4">
                <Button variant="outline" className="flex-1">
                  Update Payment Method
                </Button>
                <Button 
                  variant="destructive" 
                  className="flex-1"
                  onClick={handleCancelSubscription}
                >
                  Cancel Subscription
                </Button>
              </div>
              
              <p className="text-xs text-gray-500 text-center">
                Cancellation takes effect at the end of your current billing period.
              </p>
            </CardContent>
          </Card>
        )}

        {/* FAQ Section */}
        <div className="max-w-2xl mx-auto mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium text-gray-900 mb-2">Can I cancel anytime?</h4>
                <p className="text-sm text-gray-600">
                  Yes, you can cancel your subscription at any time. Your access will continue until the end of your current billing period.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium text-gray-900 mb-2">What happens to my data if I cancel?</h4>
                <p className="text-sm text-gray-600">
                  Your data is preserved for 30 days after cancellation. You can export your data anytime from the Analytics page.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium text-gray-900 mb-2">Is there a refund policy?</h4>
                <p className="text-sm text-gray-600">
                  We offer a 7-day money-back guarantee for all new subscriptions. Contact support for refund requests.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}