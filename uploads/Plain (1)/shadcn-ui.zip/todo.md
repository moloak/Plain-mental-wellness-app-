# Plain Web Application - MVP Development Plan

## Core Files to Create (Max 8 files)

### 1. **src/pages/Index.tsx** - Landing/Dashboard Page
- Welcome page with login/signup options
- Dashboard view for authenticated users
- Time tracking interface
- Quick stats overview

### 2. **src/pages/Auth.tsx** - Authentication Page
- Login and registration forms
- AI agent selection (Dan/Jemma) during signup
- Form validation and error handling

### 3. **src/pages/Dashboard.tsx** - Main Dashboard
- Manual time tracking for apps/activities
- Add/remove apps for monitoring
- Current day usage overview
- Quick action buttons

### 4. **src/pages/Analytics.tsx** - Analytics & Reports
- Weekly/daily usage charts
- Data visualization with charts
- Usage patterns and insights
- Email report settings

### 5. **src/pages/Subscription.tsx** - Subscription Management
- Pricing plans (₦3,000/month, ₦30,000/year)
- 7-day free trial information
- Intasend payment integration (mock)
- Subscription status and billing

### 6. **src/components/TimeTracker.tsx** - Time Tracking Component
- Manual time entry form
- App selection dropdown
- Timer functionality
- Usage progress indicators

### 7. **src/components/AppCard.tsx** - App Monitoring Card
- Individual app usage display
- Progress bars for usage limits
- Quick actions (edit limits, remove)
- Usage statistics

### 8. **src/lib/mockData.ts** - Mock Data & Services
- Sample user data
- Mock time tracking entries
- Subscription plans data
- API simulation functions

## Key Features Implementation:
- ✅ User authentication (mock)
- ✅ Manual time tracking
- ✅ Dashboard with analytics
- ✅ AI agent selection
- ✅ Subscription management
- ✅ Mobile-responsive design
- ✅ Data visualization
- ✅ Email functionality (mock)

## Technology Stack:
- React 18 + TypeScript
- Shadcn-ui components
- Tailwind CSS
- React Router for navigation
- Recharts for data visualization
- Local storage for data persistence

## MVP Scope:
Focus on core functionality with mock backend services. Real integrations (Intasend, email service) will be simulated for demonstration purposes.